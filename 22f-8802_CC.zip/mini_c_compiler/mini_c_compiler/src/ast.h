#ifndef AST_H
#define AST_H

/* ── Node types ── */
typedef enum {
    NODE_PROGRAM, NODE_FUNC_DECL, NODE_PARAM_LIST, NODE_PARAM,
    NODE_BODY, NODE_VAR_DECL, NODE_ASSIGN,
    NODE_IF, NODE_WHILE, NODE_FOR, NODE_RETURN,
    NODE_PRINTF,
    NODE_BINOP, NODE_NUM, NODE_ID, NODE_FUNC_CALL,
    NODE_ARG_LIST
} NodeType;

/* ── AST node ── */
typedef struct ASTNode {
    NodeType type;
    char    *sval;          /* identifier / operator string */
    int      ival;          /* integer literal value */
    struct ASTNode *left;
    struct ASTNode *right;
    struct ASTNode *extra;  /* third child (for-init, for-cond, for-inc / func body) */
    struct ASTNode *next;   /* sibling list (stmt lists, arg lists) */
} ASTNode;

ASTNode *make_node(NodeType type);
ASTNode *make_num(int val);
ASTNode *make_id(const char *name);
ASTNode *make_binop(const char *op, ASTNode *l, ASTNode *r);
void     free_ast(ASTNode *n);

/* ── Symbol table ── */
#define MAX_SYMS 256

typedef struct Symbol {
    char  name[64];
    char  type[16];
    char  scope[64];
    int   line;
    char  status[8];
} Symbol;

extern Symbol sym_table[MAX_SYMS];
extern int    sym_count;

int  sym_lookup(const char *name, const char *scope);
int  sym_lookup_any(const char *name);
void sym_insert(const char *name, const char *type,
                const char *scope, int line);

/* ── TAC ── */
#define MAX_TAC 1024

typedef struct TACInstr {
    char result[64];
    char arg1[64];
    char op[8];
    char arg2[64];
    /* special kinds: label, goto, ifgoto, param, call, ret, printf */
    char kind[16];   /* "assign","label","goto","ifgoto","param","call","ret","printf" */
} TACInstr;

extern TACInstr tac[MAX_TAC];
extern int      tac_count;
extern int      temp_count;
extern int      label_count;

char *new_temp(void);
char *new_label(void);
void  emit(const char *kind, const char *res, const char *a1,
           const char *op, const char *a2);

/* ── Global flags ── */
extern int print_tokens;
extern int line_number;

#endif
