#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

/* ─── Extern declarations ─── */
extern int      yyparse(void);
extern FILE    *yyin;
extern ASTNode *ast_root;
extern int      line_number;

void print_parse_tree(ASTNode *root);
void run_semantic_analysis(ASTNode *root);
void run_tac_generation(ASTNode *root);
void run_optimization(void);
void run_target_codegen(void);
void run_interpreter(void);

/* Flag: print tokens in Phase 1 */
int print_tokens = 0;

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <source.c>\n", argv[0]);
        return 1;
    }

    yyin = fopen(argv[1], "r");
    if (!yyin) {
        perror("Cannot open file");
        return 1;
    }

    /* ─── PHASE 1: Lexical Analysis ─── */
    printf("\n");
    printf("=======================================================\n");
    printf("  PHASE 1: LEXICAL ANALYSIS (TOKEN STREAM)\n");
    printf("=======================================================\n");
    printf("| %-20s | %-20s | %-8s |\n",
           "Token Value", "Token Type", "Line No.");
    printf("|----------------------|----------------------|----------|\n");

    print_tokens = 1;
    line_number  = 1;

    int parse_result = yyparse();
    fclose(yyin);
    print_tokens = 0;

    printf("|----------------------|----------------------|----------|\n");

    if (parse_result != 0 || !ast_root) {
        fprintf(stderr, "\n[ABORT] Compilation stopped due to syntax errors.\n");
        return 1;
    }

    /* ─── PHASE 2: Parse Tree ─── */
    print_parse_tree(ast_root);

    /* ─── PHASE 3: Semantic Analysis ─── */
    run_semantic_analysis(ast_root);

    /* ─── PHASE 4: TAC Generation ─── */
    run_tac_generation(ast_root);

    /* ─── PHASE 5: Optimization ─── */
    run_optimization();

    /* ─── PHASE 6: Target Code Generation ─── */
    run_target_codegen();

    /* ─── PHASE 7: Interpretation / Execution ─── */
    run_interpreter();

    printf("\n=======================================================\n");
    printf("  Compilation Complete.\n");
    printf("=======================================================\n\n");

    free_ast(ast_root);
    return 0;
}
