#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ast.h"

/* ─── Helpers ─── */
static int is_number(const char *s) {
    if (!s || !*s) return 0;
    const char *p = s; if (*p=='-') p++;
    while (*p) { if (!isdigit((unsigned char)*p)) return 0; p++; }
    return 1;
}

/* ─── Collect variable names from symbol table (non-temporaries) ─── */
static int is_temp(const char *s) {
    return s && s[0]=='t' && isdigit((unsigned char)s[1]);
}

/* ─── Generate x86-style pseudo-assembly ─── */
void run_target_codegen(void) {
    printf("\n");
    printf("=======================================================\n");
    printf("  PHASE 6: TARGET CODE GENERATION (x86 Pseudo-Assembly)\n");
    printf("=======================================================\n");

    /* ── .data section ── */
    printf("\nsection .data\n");
    /* collect unique real variable names */
    char seen[MAX_SYMS][64];
    int  seen_count = 0;

    for (int i = 0; i < tac_count; i++) {
        TACInstr *t = &tac[i];
        const char *cands[] = { t->result, t->arg1, t->arg2, NULL };
        for (int c = 0; cands[c]; c++) {
            const char *name = cands[c];
            if (!name || !*name) continue;
            if (is_number(name)) continue;
            if (is_temp(name)) continue;
            if (strcmp(t->kind,"label")==0 && c==0) continue; /* labels */
            if (strcmp(t->kind,"goto")==0  && c==0) continue;
            if (strcmp(t->kind,"ifgoto")==0 && c==3) continue;
            if (strcmp(t->kind,"call")==0  && c==1) continue;
            if (strcmp(t->kind,"printf")==0) continue;
            if (name[0]=='L') continue; /* jump labels */
            /* check not duplicate */
            int dup = 0;
            for (int j = 0; j < seen_count; j++)
                if (strcmp(seen[j], name)==0) { dup=1; break; }
            if (!dup) {
                printf("    %-10s dd 0\n", name);
                strncpy(seen[seen_count++], name, 63);
            }
        }
    }

    /* ── .text section ── */
    printf("\nsection .text\n");
    printf("global _start\n");

    for (int i = 0; i < tac_count; i++) {
        TACInstr *t = &tac[i];

        if (strcmp(t->kind,"label")==0) {
            printf("\n%s:\n", t->result);
            continue;
        }

        if (strcmp(t->kind,"assign")==0) {
            if (strlen(t->op)>0) {
                /* binary op */
                if (is_number(t->arg1))
                    printf("    MOV  EAX, %s\n", t->arg1);
                else
                    printf("    MOV  EAX, [%s]\n", t->arg1);

                if (strcmp(t->op,"+")==0) {
                    if (is_number(t->arg2)) printf("    ADD  EAX, %s\n", t->arg2);
                    else                    printf("    ADD  EAX, [%s]\n", t->arg2);
                } else if (strcmp(t->op,"-")==0) {
                    if (is_number(t->arg2)) printf("    SUB  EAX, %s\n", t->arg2);
                    else                    printf("    SUB  EAX, [%s]\n", t->arg2);
                } else if (strcmp(t->op,"*")==0) {
                    if (is_number(t->arg2)) {
                        printf("    MOV  EBX, %s\n", t->arg2);
                        printf("    IMUL EAX, EBX\n");
                    } else {
                        printf("    IMUL EAX, [%s]\n", t->arg2);
                    }
                } else if (strcmp(t->op,"/")==0) {
                    printf("    CDQ\n");
                    if (is_number(t->arg2)) {
                        printf("    MOV  EBX, %s\n", t->arg2);
                        printf("    IDIV EBX\n");
                    } else {
                        printf("    IDIV DWORD [%s]\n", t->arg2);
                    }
                } else {
                    /* relational: use CMP + SETXX */
                    if (is_number(t->arg2)) printf("    CMP  EAX, %s\n", t->arg2);
                    else                    printf("    CMP  EAX, [%s]\n", t->arg2);
                    if      (strcmp(t->op,"<")==0)  printf("    SETL AL\n");
                    else if (strcmp(t->op,">")==0)  printf("    SETG AL\n");
                    else if (strcmp(t->op,"<=")==0) printf("    SETLE AL\n");
                    else if (strcmp(t->op,">=")==0) printf("    SETGE AL\n");
                    else if (strcmp(t->op,"==")==0) printf("    SETE AL\n");
                    else if (strcmp(t->op,"!=")==0) printf("    SETNE AL\n");
                    printf("    MOVZX EAX, AL\n");
                }
            } else {
                /* simple move */
                if (is_number(t->arg1))
                    printf("    MOV  EAX, %s\n", t->arg1);
                else
                    printf("    MOV  EAX, [%s]\n", t->arg1);
            }
            /* store result */
            if (is_temp(t->result))
                printf("    PUSH EAX          ; save %s\n", t->result);
            else
                printf("    MOV  [%s], EAX\n", t->result);
            continue;
        }

        if (strcmp(t->kind,"goto")==0) {
            printf("    JMP  %s\n", t->result);
            continue;
        }

        if (strcmp(t->kind,"ifgoto")==0) {
            if (is_number(t->arg1))
                printf("    MOV  EAX, %s\n", t->arg1);
            else
                printf("    MOV  EAX, [%s]\n", t->arg1);
            printf("    CMP  EAX, %s\n", t->arg2);
            printf("    JE   %s\n", t->result);   /* jump if equal to 0 (false) */
            continue;
        }

        if (strcmp(t->kind,"param")==0) {
            if (is_number(t->arg1))
                printf("    PUSH %s\n", t->arg1);
            else
                printf("    PUSH DWORD [%s]\n", t->arg1);
            continue;
        }

        if (strcmp(t->kind,"call")==0) {
            printf("    CALL %s\n", t->arg1);
            printf("    ; result in EAX\n");
            if (is_temp(t->result))
                printf("    PUSH EAX          ; save %s\n", t->result);
            else
                printf("    MOV  [%s], EAX\n", t->result);
            continue;
        }

        if (strcmp(t->kind,"ret")==0) {
            if (is_number(t->arg1))
                printf("    MOV  EAX, %s\n", t->arg1);
            else
                printf("    MOV  EAX, [%s]\n", t->arg1);
            printf("    RET\n");
            continue;
        }

        if (strcmp(t->kind,"printf")==0) {
            printf("    ; printf %s\n", t->result);
            printf("    CALL printf\n");
            printf("    ADD  ESP, 4        ; clean stack\n");
            continue;
        }
    }

    printf("\n    ; === Program End ===\n");
    printf("    MOV  EAX, 1        ; sys_exit\n");
    printf("    XOR  EBX, EBX\n");
    printf("    INT  0x80\n");
}
