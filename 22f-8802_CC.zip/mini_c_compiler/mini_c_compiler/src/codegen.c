#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

/* forward */
static char *gen_expr(ASTNode *n);
static void  gen_stmt(ASTNode *n);

/* ─── Expression code generation ─── returns place (temp / literal / id) ─── */
static char *gen_expr(ASTNode *n) {
    if (!n) return strdup("0");

    if (n->type == NODE_NUM) {
        char *buf = malloc(32);
        sprintf(buf, "%d", n->ival);
        return buf;
    }
    if (n->type == NODE_ID) {
        return strdup(n->sval);
    }
    if (n->type == NODE_BINOP) {
        char *l = gen_expr(n->left);
        char *r = gen_expr(n->right);
        char *t = new_temp();
        emit("assign", t, l, n->sval, r);
        free(l); free(r);
        return t;
    }
    if (n->type == NODE_FUNC_CALL) {
        /* push args */
        ASTNode *arg = n->left;
        while (arg) {
            char *av = gen_expr(arg->left);
            emit("param", "", av, "", "");
            free(av);
            arg = arg->next;
        }
        char *t = new_temp();
        emit("call", t, n->sval, "", "");
        return t;
    }
    return strdup("?");
}

/* ─── Statement code generation ─── */
static void gen_stmt(ASTNode *n) {
    if (!n) return;

    switch (n->type) {

    case NODE_VAR_DECL:
        if (n->left) {
            char *val = gen_expr(n->left);
            emit("assign", n->sval, val, "", "");
            free(val);
        }
        break;

    case NODE_ASSIGN: {
        char *val = gen_expr(n->left);
        emit("assign", n->sval, val, "", "");
        free(val);
        break;
    }

    case NODE_IF: {
        char *cond = gen_expr(n->left);
        char *lelse = new_label();
        char *lend  = new_label();

        /* if NOT cond goto lelse */
        emit("ifgoto", lelse, cond, "==", "0");
        free(cond);

        /* then body */
        if (n->right) gen_stmt(n->right->left);

        if (n->extra) {
            emit("goto", lend, "", "", "");
            emit("label", lelse, "", "", "");
            gen_stmt(n->extra->left);
            emit("label", lend, "", "", "");
        } else {
            emit("label", lelse, "", "", "");
        }
        free(lelse); free(lend);
        break;
    }

    case NODE_WHILE: {
        char *lstart = new_label();
        char *lend   = new_label();
        emit("label", lstart, "", "", "");
        char *cond = gen_expr(n->left);
        emit("ifgoto", lend, cond, "==", "0");
        free(cond);
        if (n->right) gen_stmt(n->right->left);
        emit("goto", lstart, "", "", "");
        emit("label", lend, "", "", "");
        free(lstart); free(lend);
        break;
    }

    case NODE_FOR: {
        /* init */
        gen_stmt(n->left);
        char *lstart = new_label();
        char *lend   = new_label();
        emit("label", lstart, "", "", "");
        char *cond = gen_expr(n->right);
        emit("ifgoto", lend, cond, "==", "0");
        free(cond);
        /* body */
        gen_stmt(n->extra->left);
        /* update (stored as extra->next which is an assign_stmt) */
        if (n->extra->next) gen_stmt(n->extra->next);
        emit("goto", lstart, "", "", "");
        emit("label", lend, "", "", "");
        free(lstart); free(lend);
        break;
    }

    case NODE_RETURN: {
        if (n->left) {
            char *val = gen_expr(n->left);
            emit("ret", "", val, "", "");
            free(val);
        } else {
            emit("ret", "", "0", "", "");
        }
        break;
    }

    case NODE_PRINTF: {
        if (n->left) {
            ASTNode *arg = n->left;
            while (arg) {
                char *av = gen_expr(arg->left);
                emit("param", "", av, "", "");
                free(av);
                arg = arg->next;
            }
        }
        emit("printf", n->sval, "", "", "");
        break;
    }

    case NODE_FUNC_CALL: {
        /* call but discard result */
        ASTNode *arg = n->left;
        while (arg) {
            char *av = gen_expr(arg->left);
            emit("param", "", av, "", "");
            free(av);
            arg = arg->next;
        }
        char *t = new_temp();
        emit("call", t, n->sval, "", "");
        free(t);
        break;
    }

    case NODE_BODY:
        gen_stmt(n->left);
        break;

    default: break;
    }

    /* sibling */
    gen_stmt(n->next);
}

/* ─── Walk functions ─── */
static void gen_func(ASTNode *n) {
    if (!n) return;
    emit("label", n->sval, "", "", "");   /* function label */
    gen_stmt(n->right);                   /* body */
    gen_func(n->next);
}

/* ─── Print one TAC instruction ─── */
static void print_tac_instr(int i) {
    TACInstr *t = &tac[i];
    if (strcmp(t->kind, "assign") == 0) {
        if (strlen(t->op) > 0)
            printf("    %s = %s %s %s\n",
                   t->result, t->arg1, t->op, t->arg2);
        else
            printf("    %s = %s\n", t->result, t->arg1);
    } else if (strcmp(t->kind, "label") == 0) {
        printf("  %s:\n", t->result);
    } else if (strcmp(t->kind, "goto") == 0) {
        printf("    goto %s\n", t->result);
    } else if (strcmp(t->kind, "ifgoto") == 0) {
        printf("    if %s %s %s goto %s\n",
               t->arg1, t->op, t->arg2, t->result);
    } else if (strcmp(t->kind, "param") == 0) {
        printf("    param %s\n", t->arg1);
    } else if (strcmp(t->kind, "call") == 0) {
        printf("    %s = call %s\n", t->result, t->arg1);
    } else if (strcmp(t->kind, "ret") == 0) {
        printf("    return %s\n", t->arg1);
    } else if (strcmp(t->kind, "printf") == 0) {
        printf("    printf %s\n", t->result);
    }
}

/* ─── Public entry ─── */
void run_tac_generation(ASTNode *root) {
    tac_count = temp_count = label_count = 0;

    gen_func(root->left);

    printf("\n");
    printf("=======================================================\n");
    printf("  PHASE 4: INTERMEDIATE CODE (THREE-ADDRESS CODE)\n");
    printf("=======================================================\n");
    for (int i = 0; i < tac_count; i++)
        print_tac_instr(i);
}
