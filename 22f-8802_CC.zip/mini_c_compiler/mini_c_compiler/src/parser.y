%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

extern int  yylex(void);
extern int  line_number;
void yyerror(const char *s);

ASTNode *ast_root = NULL;

/* indent helper for parse tree printing */
static void print_tree(ASTNode *n, int depth);
static void indent(int d){ for(int i=0;i<d;i++) printf("  "); }
%}

%union {
    int      ival;
    char    *sval;
    ASTNode *node;
}

%token <ival> NUMBER
%token <sval> ID STRING
%token INT IF ELSE WHILE FOR RETURN PRINTF
%token PLUS MINUS MUL DIV
%token ASSIGN EQ NEQ LT GT LEQ GEQ
%token LPAREN RPAREN LBRACE RBRACE SEMI COMMA

%type <node> program func_list func_decl param_list param_item
%type <node> body stmt_list stmt
%type <node> var_decl assign_stmt if_stmt while_stmt for_stmt
%type <node> return_stmt printf_stmt func_call arg_list expr

/* precedence */
%right ASSIGN
%left  EQ NEQ
%left  LT GT LEQ GEQ
%left  PLUS MINUS
%left  MUL DIV
%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%

program
    : func_list
        { ASTNode *n = make_node(NODE_PROGRAM);
          n->left = $1; ast_root = n; $$ = n; }
    ;

func_list
    : func_decl             { $$ = $1; }
    | func_list func_decl   { $1->next = $2; $$ = $1; }
    ;

func_decl
    : INT ID LPAREN param_list RPAREN LBRACE body RBRACE
        { ASTNode *n = make_node(NODE_FUNC_DECL);
          n->sval  = $2;
          n->left  = $4;   /* params */
          n->right = $7;   /* body   */
          $$ = n; }
    | INT ID LPAREN RPAREN LBRACE body RBRACE
        { ASTNode *n = make_node(NODE_FUNC_DECL);
          n->sval  = $2;
          n->left  = NULL;
          n->right = $6;
          $$ = n; }
    ;

param_list
    : param_item                    { $$ = $1; }
    | param_list COMMA param_item   { $1->next = $3; $$ = $1; }
    ;

param_item
    : INT ID
        { ASTNode *n = make_node(NODE_PARAM);
          n->sval = $2; $$ = n; }
    ;

body
    : stmt_list
        { ASTNode *n = make_node(NODE_BODY);
          n->left = $1; $$ = n; }
    |   { ASTNode *n = make_node(NODE_BODY);
          n->left = NULL; $$ = n; }
    ;

stmt_list
    : stmt              { $$ = $1; }
    | stmt_list stmt    { /* append to end of sibling list */
        ASTNode *cur = $1;
        while(cur->next) cur = cur->next;
        cur->next = $2; $$ = $1; }
    ;

stmt
    : var_decl      { $$ = $1; }
    | assign_stmt   { $$ = $1; }
    | if_stmt       { $$ = $1; }
    | while_stmt    { $$ = $1; }
    | for_stmt      { $$ = $1; }
    | return_stmt   { $$ = $1; }
    | printf_stmt   { $$ = $1; }
    | func_call SEMI{ $$ = $1; }
    ;

var_decl
    : INT ID SEMI
        { ASTNode *n = make_node(NODE_VAR_DECL);
          n->sval = $2; n->left = NULL; $$ = n; }
    | INT ID ASSIGN expr SEMI
        { ASTNode *n = make_node(NODE_VAR_DECL);
          n->sval = $2; n->left = $4; $$ = n; }
    ;

assign_stmt
    : ID ASSIGN expr SEMI
        { ASTNode *n = make_node(NODE_ASSIGN);
          n->sval = $1; n->left = $3; $$ = n; }
    ;

if_stmt
    : IF LPAREN expr RPAREN LBRACE body RBRACE %prec LOWER_THAN_ELSE
        { ASTNode *n = make_node(NODE_IF);
          n->left  = $3;   /* condition */
          n->right = $6;   /* then-body */
          n->extra = NULL;
          $$ = n; }
    | IF LPAREN expr RPAREN LBRACE body RBRACE ELSE LBRACE body RBRACE
        { ASTNode *n = make_node(NODE_IF);
          n->left  = $3;
          n->right = $6;
          n->extra = $10;
          $$ = n; }
    ;

while_stmt
    : WHILE LPAREN expr RPAREN LBRACE body RBRACE
        { ASTNode *n = make_node(NODE_WHILE);
          n->left  = $3;
          n->right = $6;
          $$ = n; }
    ;

for_stmt
    : FOR LPAREN var_decl expr SEMI assign_stmt RPAREN LBRACE body RBRACE
        { ASTNode *n = make_node(NODE_FOR);
          n->left  = $3;   /* init */
          n->right = $4;   /* cond */
          n->extra = $9;   /* body */
          /* store update as extra->next */
          n->extra->next = $6;
          $$ = n; }
    ;

return_stmt
    : RETURN expr SEMI
        { ASTNode *n = make_node(NODE_RETURN);
          n->left = $2; $$ = n; }
    | RETURN SEMI
        { ASTNode *n = make_node(NODE_RETURN);
          n->left = NULL; $$ = n; }
    ;

printf_stmt
    : PRINTF LPAREN STRING RPAREN SEMI
        { ASTNode *n = make_node(NODE_PRINTF);
          n->sval = $3; n->left = NULL; $$ = n; }
    | PRINTF LPAREN STRING COMMA arg_list RPAREN SEMI
        { ASTNode *n = make_node(NODE_PRINTF);
          n->sval = $3; n->left = $5; $$ = n; }
    ;

func_call
    : ID LPAREN arg_list RPAREN
        { ASTNode *n = make_node(NODE_FUNC_CALL);
          n->sval = $1; n->left = $3; $$ = n; }
    | ID LPAREN RPAREN
        { ASTNode *n = make_node(NODE_FUNC_CALL);
          n->sval = $1; n->left = NULL; $$ = n; }
    ;

arg_list
    : expr                  { ASTNode *n = make_node(NODE_ARG_LIST);
                              n->left = $1; $$ = n; }
    | arg_list COMMA expr   { ASTNode *n = make_node(NODE_ARG_LIST);
                              n->left = $3; $1->next = n; $$ = $1; }
    ;

expr
    : expr PLUS  expr { $$ = make_binop("+", $1, $3); }
    | expr MINUS expr { $$ = make_binop("-", $1, $3); }
    | expr MUL   expr { $$ = make_binop("*", $1, $3); }
    | expr DIV   expr { $$ = make_binop("/", $1, $3); }
    | expr EQ    expr { $$ = make_binop("==", $1, $3); }
    | expr NEQ   expr { $$ = make_binop("!=", $1, $3); }
    | expr LT    expr { $$ = make_binop("<",  $1, $3); }
    | expr GT    expr { $$ = make_binop(">",  $1, $3); }
    | expr LEQ   expr { $$ = make_binop("<=", $1, $3); }
    | expr GEQ   expr { $$ = make_binop(">=", $1, $3); }
    | LPAREN expr RPAREN { $$ = $2; }
    | NUMBER     { $$ = make_num($1); }
    | ID         { $$ = make_id($1); }
    | func_call  { $$ = $1; }
    ;

%%

void yyerror(const char *s) {
    fprintf(stderr, "\n[ERROR] Syntax Error at line %d: %s\n", line_number, s);
}

/* ─── Parse Tree Printer ─── */
static void print_tree(ASTNode *n, int depth) {
    if (!n) return;
    const char *names[] = {
        "Program","FuncDecl","ParamList","Param",
        "Body","VarDecl","AssignStmt",
        "IfStmt","WhileStmt","ForStmt","ReturnStmt",
        "PrintfStmt",
        "BinaryExpr","IntLiteral","Identifier","FuncCall",
        "ArgList"
    };
    indent(depth);
    if (depth > 0) printf("|-- ");
    switch(n->type){
        case NODE_NUM:      printf("IntLiteral: %d\n", n->ival); break;
        case NODE_ID:       printf("Identifier: %s\n", n->sval); break;
        case NODE_BINOP:    printf("BinaryExpr: %s\n", n->sval); break;
        case NODE_FUNC_DECL:printf("FuncDecl: %s\n",   n->sval); break;
        case NODE_VAR_DECL: printf("VarDecl: int %s\n",n->sval); break;
        case NODE_ASSIGN:   printf("AssignStmt: %s\n", n->sval); break;
        case NODE_PARAM:    printf("Param: int %s\n",  n->sval); break;
        case NODE_FUNC_CALL:printf("FuncCall: %s\n",   n->sval); break;
        case NODE_PRINTF:   printf("PrintfStmt: %s\n", n->sval); break;
        default: printf("%s\n", names[n->type]);
    }
    /* children */
    if (n->left)  print_tree(n->left,  depth+1);
    if (n->right) print_tree(n->right, depth+1);
    if (n->extra) print_tree(n->extra, depth+1);
    /* siblings */
    if (n->next)  print_tree(n->next,  depth);
}

void print_parse_tree(ASTNode *root){
    printf("\n");
    printf("=======================================================\n");
    printf("  PHASE 2: SYNTAX ANALYSIS – PARSE TREE\n");
    printf("=======================================================\n");
    print_tree(root, 0);
}
