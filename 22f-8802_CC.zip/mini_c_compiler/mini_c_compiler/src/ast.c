#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

/* ─── Symbol Table ─── */
Symbol sym_table[MAX_SYMS];
int    sym_count = 0;

int sym_lookup(const char *name, const char *scope) {
    for (int i = 0; i < sym_count; i++)
        if (strcmp(sym_table[i].name, name) == 0 &&
            strcmp(sym_table[i].scope, scope) == 0)
            return i;
    return -1;
}

int sym_lookup_any(const char *name) {
    for (int i = 0; i < sym_count; i++)
        if (strcmp(sym_table[i].name, name) == 0)
            return i;
    return -1;
}

void sym_insert(const char *name, const char *type,
                const char *scope, int line) {
    strncpy(sym_table[sym_count].name,  name,  63);
    strncpy(sym_table[sym_count].type,  type,  15);
    strncpy(sym_table[sym_count].scope, scope, 63);
    sym_table[sym_count].line = line;
    strcpy (sym_table[sym_count].status, "OK");
    sym_count++;
}

/* ─── TAC storage ─── */
TACInstr tac[MAX_TAC];
int      tac_count  = 0;
int      temp_count = 0;
int      label_count = 0;

char *new_temp(void) {
    char *buf = malloc(16);
    sprintf(buf, "t%d", ++temp_count);
    return buf;
}

char *new_label(void) {
    char *buf = malloc(16);
    sprintf(buf, "L%d", ++label_count);
    return buf;
}

void emit(const char *kind, const char *res,
          const char *a1, const char *op, const char *a2) {
    TACInstr *t = &tac[tac_count++];
    strncpy(t->kind,   kind ? kind : "",   15);
    strncpy(t->result, res  ? res  : "",   63);
    strncpy(t->arg1,   a1   ? a1   : "",   63);
    strncpy(t->op,     op   ? op   : "",   7);
    strncpy(t->arg2,   a2   ? a2   : "",   63);
}

/* ─── AST construction ─── */
ASTNode *make_node(NodeType type) {
    ASTNode *n = calloc(1, sizeof(ASTNode));
    n->type = type;
    return n;
}

ASTNode *make_num(int val) {
    ASTNode *n = make_node(NODE_NUM);
    n->ival = val;
    return n;
}

ASTNode *make_id(const char *name) {
    ASTNode *n = make_node(NODE_ID);
    n->sval = strdup(name);
    return n;
}

ASTNode *make_binop(const char *op, ASTNode *l, ASTNode *r) {
    ASTNode *n = make_node(NODE_BINOP);
    n->sval  = strdup(op);
    n->left  = l;
    n->right = r;
    return n;
}

void free_ast(ASTNode *n) {
    if (!n) return;
    free_ast(n->left);
    free_ast(n->right);
    free_ast(n->extra);
    free_ast(n->next);
    if (n->sval) free(n->sval);
    free(n);
}
