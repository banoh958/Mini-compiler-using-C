#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ast.h"

/* ─── Runtime environment ─── */
#define MAX_VARS 256
#define MAX_STACK 64

typedef struct { char name[64]; int val; } RtVar;

static RtVar rt_vars[MAX_VARS];
static int   rt_count = 0;

static int   param_stack[MAX_STACK];
static int   param_top = 0;

static int is_number(const char *s) {
    if (!s||!*s) return 0;
    const char *p=s; if(*p=='-')p++;
    while(*p){if(!isdigit((unsigned char)*p))return 0;p++;}
    return 1;
}

static int rt_get(const char *name) {
    if (is_number(name)) return atoi(name);
    for (int i=0;i<rt_count;i++)
        if(strcmp(rt_vars[i].name,name)==0) return rt_vars[i].val;
    return 0;
}

static void rt_set(const char *name, int val) {
    if (!name||!*name||is_number(name)) return;
    for (int i=0;i<rt_count;i++)
        if(strcmp(rt_vars[i].name,name)==0){rt_vars[i].val=val;return;}
    strncpy(rt_vars[rt_count].name,name,63);
    rt_vars[rt_count].val=val;
    rt_count++;
}

static int eval_op(int a,const char *op,int b){
    if(strcmp(op,"+")==0) return a+b;
    if(strcmp(op,"-")==0) return a-b;
    if(strcmp(op,"*")==0) return a*b;
    if(strcmp(op,"/")==0) return b?a/b:0;
    if(strcmp(op,"<")==0) return a<b;
    if(strcmp(op,">")==0) return a>b;
    if(strcmp(op,"<=")==0)return a<=b;
    if(strcmp(op,">=")==0)return a>=b;
    if(strcmp(op,"==")==0)return a==b;
    if(strcmp(op,"!=")==0)return a!=b;
    return 0;
}

/* Find label index */
static int find_label(const char *lbl){
    for(int i=0;i<tac_count;i++)
        if(strcmp(tac[i].kind,"label")==0 &&
           strcmp(tac[i].result,lbl)==0) return i;
    return -1;
}

/* Format printf string with runtime value */
static void do_printf(const char *fmt_raw, int val) {
    /* strip surrounding quotes */
    char fmt[256]; strncpy(fmt,fmt_raw,255);
    int len=(int)strlen(fmt);
    if(len>=2 && fmt[0]=='"' && fmt[len-1]=='"'){
        fmt[len-1]='\0';
        memmove(fmt,fmt+1,strlen(fmt));
    }
    /* replace %d with value */
    char *pos=strstr(fmt,"%d");
    if(pos){
        *pos='\0';
        printf("%s%d%s",fmt,val,pos+2);
    } else {
        printf("%s",fmt);
    }
}

/* ─── Execute TAC interpreter ─── */
static int execute(int start, int *ret_val) {
    int ip = start;
    while(ip < tac_count){
        TACInstr *t = &tac[ip];

        if(strcmp(t->kind,"label")==0){ ip++; continue; }

        if(strcmp(t->kind,"assign")==0){
            int val;
            if(strlen(t->op)>0)
                val = eval_op(rt_get(t->arg1),t->op,rt_get(t->arg2));
            else
                val = rt_get(t->arg1);
            rt_set(t->result, val);
            ip++; continue;
        }

        if(strcmp(t->kind,"goto")==0){
            int lbl=find_label(t->result);
            if(lbl<0){fprintf(stderr,"[EXEC] Label not found: %s\n",t->result);break;}
            ip=lbl; continue;
        }

        if(strcmp(t->kind,"ifgoto")==0){
            int a=rt_get(t->arg1);
            int b=rt_get(t->arg2);
            int cond=eval_op(a,t->op,b);
            if(cond){
                int lbl=find_label(t->result);
                if(lbl<0){fprintf(stderr,"[EXEC] Label not found: %s\n",t->result);break;}
                ip=lbl;
            } else {
                ip++;
            }
            continue;
        }

        if(strcmp(t->kind,"param")==0){
            if(param_top<MAX_STACK)
                param_stack[param_top++]=rt_get(t->arg1);
            ip++; continue;
        }

        if(strcmp(t->kind,"call")==0){
            /* find function label */
            int flbl=find_label(t->arg1);
            if(flbl<0){
                /* built-in or external: just push 0 */
                rt_set(t->result,0);
                param_top=0;
                ip++; continue;
            }
            int rv=0;
            execute(flbl+1,&rv);
            rt_set(t->result,rv);
            param_top=0;
            ip++; continue;
        }

        if(strcmp(t->kind,"ret")==0){
            if(ret_val) *ret_val=rt_get(t->arg1);
            return 1;
        }

        if(strcmp(t->kind,"printf")==0){
            /* pop params */
            int pval = (param_top>0) ? param_stack[--param_top] : 0;
            param_top=0;
            do_printf(t->result, pval);
            ip++; continue;
        }

        ip++;
    }
    return 0;
}

/* ─── Public entry ─── */
void run_interpreter(void) {
    printf("\n");
    printf("=======================================================\n");
    printf("  PHASE 7: PROGRAM EXECUTION (TAC Interpreter)\n");
    printf("=======================================================\n");
    printf("\n  Program Output:\n");
    printf("  -------------------------------------------------------\n  ");

    rt_count=0; param_top=0;

    /* Find 'main' label and start from there */
    int main_lbl = find_label("main");
    if(main_lbl<0){
        /* No main found: execute from start */
        main_lbl=0;
    }

    int rv=0;
    execute(main_lbl, &rv);

    printf("\n  -------------------------------------------------------\n");
    printf("  Return value: %d\n", rv);
}
