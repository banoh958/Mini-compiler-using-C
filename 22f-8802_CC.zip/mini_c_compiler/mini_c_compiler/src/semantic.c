#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

static int sem_errors = 0;
static char current_scope[64] = "global";

/* forward */
static void analyse_node(ASTNode *n);
static void analyse_expr(ASTNode *n);

/* ─── expression semantic check ─── */
static void analyse_expr(ASTNode *n) {
    if (!n) return;
    if (n->type == NODE_ID) {
        if (sym_lookup_any(n->sval) < 0) {
            fprintf(stderr,
                "[SEM ERROR] Undeclared variable '%s' used in scope '%s'\n",
                n->sval, current_scope);
            sem_errors++;
        }
    }
    analyse_expr(n->left);
    analyse_expr(n->right);
    if (n->type == NODE_FUNC_CALL) {
        /* check args */
        ASTNode *arg = n->left;
        while (arg) { analyse_expr(arg->left); arg = arg->next; }
    }
}

/* ─── statement / body traversal ─── */
static void analyse_node(ASTNode *n) {
    if (!n) return;

    switch (n->type) {

    case NODE_PROGRAM:
        analyse_node(n->left);
        break;

    case NODE_FUNC_DECL: {
        /* insert function name into global scope */
        if (sym_lookup("global", n->sval) < 0)
            sym_insert(n->sval, "int", "global", 0);

        char prev_scope[64];
        strncpy(prev_scope, current_scope, 63);
        snprintf(current_scope, 63, "%s()", n->sval);

        /* params */
        ASTNode *p = n->left;
        while (p) {
            if (sym_lookup(p->sval, current_scope) >= 0) {
                fprintf(stderr,
                    "[SEM ERROR] Duplicate param '%s' in '%s'\n",
                    p->sval, current_scope);
                sem_errors++;
            } else {
                sym_insert(p->sval, "int", current_scope, 0);
            }
            p = p->next;
        }

        analyse_node(n->right);            /* body */
        strncpy(current_scope, prev_scope, 63);

        /* sibling functions */
        analyse_node(n->next);
        break;
    }

    case NODE_BODY:
        analyse_node(n->left);
        break;

    case NODE_VAR_DECL: {
        extern int line_number;
        if (sym_lookup(n->sval, current_scope) >= 0) {
            fprintf(stderr,
                "[SEM ERROR] Duplicate declaration of '%s' in scope '%s'\n",
                n->sval, current_scope);
            sem_errors++;
        } else {
            sym_insert(n->sval, "int", current_scope, 0);
        }
        if (n->left) analyse_expr(n->left);
        analyse_node(n->next);
        break;
    }

    case NODE_ASSIGN:
        if (sym_lookup_any(n->sval) < 0) {
            fprintf(stderr,
                "[SEM ERROR] Assignment to undeclared variable '%s'\n",
                n->sval);
            sem_errors++;
        }
        analyse_expr(n->left);
        analyse_node(n->next);
        break;

    case NODE_IF:
        analyse_expr(n->left);            /* condition */
        analyse_node(n->right);           /* then      */
        if (n->extra) analyse_node(n->extra); /* else */
        analyse_node(n->next);
        break;

    case NODE_WHILE:
        analyse_expr(n->left);
        analyse_node(n->right);
        analyse_node(n->next);
        break;

    case NODE_FOR:
        analyse_node(n->left);            /* init  */
        analyse_expr(n->right);           /* cond  */
        analyse_node(n->extra);           /* body  */
        analyse_node(n->next);
        break;

    case NODE_RETURN:
        if (n->left) analyse_expr(n->left);
        analyse_node(n->next);
        break;

    case NODE_PRINTF:
        if (n->left) {
            ASTNode *arg = n->left;
            while (arg) { analyse_expr(arg->left); arg = arg->next; }
        }
        analyse_node(n->next);
        break;

    case NODE_FUNC_CALL:
        analyse_expr(n);
        analyse_node(n->next);
        break;

    default:
        analyse_node(n->next);
        break;
    }
}

/* ─── Public entry ─── */
void run_semantic_analysis(ASTNode *root) {
    printf("\n");
    printf("=======================================================\n");
    printf("  PHASE 3: SEMANTIC ANALYSIS\n");
    printf("=======================================================\n");

    sem_errors = 0;
    sym_count  = 0;
    strcpy(current_scope, "global");

    analyse_node(root);

    /* print symbol table */
    printf("\n  Symbol Table:\n");
    printf("  +----------------------+------+------------------+------+--------+\n");
    printf("  | %-20s | %-4s | %-16s | %-4s | %-6s |\n",
           "Variable","Type","Scope","Line","Status");
    printf("  +----------------------+------+------------------+------+--------+\n");
    for (int i = 0; i < sym_count; i++) {
        printf("  | %-20s | %-4s | %-16s | %-4d | %-6s |\n",
               sym_table[i].name,
               sym_table[i].type,
               sym_table[i].scope,
               sym_table[i].line,
               sym_table[i].status);
    }
    printf("  +----------------------+------+------------------+------+--------+\n");

    if (sem_errors == 0)
        printf("\n  [OK] Semantic Analysis Passed. No errors found.\n");
    else
        printf("\n  [FAIL] Semantic Analysis found %d error(s).\n", sem_errors);
}
