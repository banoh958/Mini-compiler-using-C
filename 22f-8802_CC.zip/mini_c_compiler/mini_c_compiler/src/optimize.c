#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ast.h"

/* ─── Helper: is string a numeric literal? ─── */
static int is_number(const char *s) {
    if (!s || !*s) return 0;
    const char *p = s;
    if (*p == '-') p++;
    while (*p) { if (!isdigit((unsigned char)*p)) return 0; p++; }
    return 1;
}

static int eval_op(int a, const char *op, int b) {
    if (strcmp(op,"+")==0) return a+b;
    if (strcmp(op,"-")==0) return a-b;
    if (strcmp(op,"*")==0) return a*b;
    if (strcmp(op,"/")==0) return b ? a/b : 0;
    if (strcmp(op,"<")==0) return a<b;
    if (strcmp(op,">")==0) return a>b;
    if (strcmp(op,"<=")==0) return a<=b;
    if (strcmp(op,">=")==0) return a>=b;
    if (strcmp(op,"==")==0) return a==b;
    if (strcmp(op,"!=")==0) return a!=b;
    return 0;
}

/* Track constant values of temporaries for folding */
typedef struct { char name[64]; int val; int known; } ConstVal;
static ConstVal cv[MAX_TAC];
static int      cv_count = 0;

static void cv_set(const char *name, int val) {
    for (int i = 0; i < cv_count; i++)
        if (strcmp(cv[i].name, name)==0) {
            cv[i].val = val; cv[i].known = 1; return;
        }
    strncpy(cv[cv_count].name, name, 63);
    cv[cv_count].val   = val;
    cv[cv_count].known = 1;
    cv_count++;
}

static int cv_get(const char *name, int *val) {
    if (is_number(name)) { *val = atoi(name); return 1; }
    for (int i = 0; i < cv_count; i++)
        if (strcmp(cv[i].name, name)==0 && cv[i].known) {
            *val = cv[i].val; return 1;
        }
    return 0;
}

/* ─── Dead-code: mark which temporaries are used ─── */
static int is_used(int idx, const char *name) {
    if (!name || !*name || !strcmp(name,"0")) return 1;
    if (!is_number(name) && name[0] != 't') return 1; /* real var always used */
    for (int j = idx+1; j < tac_count; j++) {
        TACInstr *t = &tac[j];
        if (strcmp(t->arg1,  name)==0) return 1;
        if (strcmp(t->arg2,  name)==0) return 1;
        if (strcmp(t->result,name)==0 && strcmp(t->kind,"label")!=0) {
            /* result is overwritten before use */
            return 0;
        }
    }
    /* function return or final assignment to real variable */
    return 0;
}

/* ─── Optimise in-place; store flags ─── */
#define FLAG_NONE  0
#define FLAG_CF    1   /* constant folding */
#define FLAG_DCE   2   /* dead code elimination */
#define FLAG_DEAD  3   /* instruction removed */

static int flags[MAX_TAC];

void run_optimization(void) {
    /* save copy of original TAC for display */
    TACInstr orig[MAX_TAC];
    int      orig_count = tac_count;
    memcpy(orig, tac, sizeof(TACInstr)*tac_count);

    cv_count = 0;
    memset(flags, 0, sizeof(flags));

    /* ── Pass 1: Constant Folding ── */
    for (int i = 0; i < tac_count; i++) {
        TACInstr *t = &tac[i];
        if (strcmp(t->kind,"assign")==0 && strlen(t->op)>0) {
            int a, b;
            if (cv_get(t->arg1, &a) && cv_get(t->arg2, &b)) {
                int res = eval_op(a, t->op, b);
                char buf[32]; sprintf(buf, "%d", res);
                strncpy(t->arg1, buf, 63);
                t->op[0] = '\0'; t->arg2[0] = '\0';
                cv_set(t->result, res);
                flags[i] = FLAG_CF;
            } else {
                int x;
                if (cv_get(t->arg1, &x)) {
                    /* propagate known value into arg1 */
                    char buf[32]; sprintf(buf, "%d", x);
                    strncpy(t->arg1, buf, 63);
                }
                if (cv_get(t->arg2, &x)) {
                    char buf[32]; sprintf(buf, "%d", x);
                    strncpy(t->arg2, buf, 63);
                }
            }
        } else if (strcmp(t->kind,"assign")==0 && strlen(t->op)==0) {
            int x;
            if (cv_get(t->arg1, &x)) cv_set(t->result, x);
        }
    }

    /* ── Pass 2: Dead Code Elimination ── */
    for (int i = 0; i < tac_count; i++) {
        TACInstr *t = &tac[i];
        if (strcmp(t->kind,"assign")==0 && t->result[0]=='t') {
            if (!is_used(i, t->result)) {
                flags[i] = (flags[i] == FLAG_CF) ? FLAG_CF : FLAG_DCE;
                /* mark as removed */
                strcpy(t->kind, "_dead_");
            }
        }
    }

    /* ── Print comparison ── */
    printf("\n");
    printf("=======================================================\n");
    printf("  PHASE 5: CODE OPTIMIZATION\n");
    printf("=======================================================\n");

    int any_opt = 0;
    for (int i = 0; i < orig_count; i++) {
        TACInstr *o = &orig[i];
        TACInstr *n = &tac[i];

        /* format original */
        char obuf[128], nbuf[128];
        if (strcmp(o->kind,"assign")==0) {
            if (strlen(o->op)>0)
                sprintf(obuf,"%s = %s %s %s",o->result,o->arg1,o->op,o->arg2);
            else
                sprintf(obuf,"%s = %s",o->result,o->arg1);
        } else if (strcmp(o->kind,"label")==0) {
            sprintf(obuf,"%s:",o->result);
        } else if (strcmp(o->kind,"goto")==0) {
            sprintf(obuf,"goto %s",o->result);
        } else if (strcmp(o->kind,"ifgoto")==0) {
            sprintf(obuf,"if %s %s %s goto %s",o->arg1,o->op,o->arg2,o->result);
        } else if (strcmp(o->kind,"param")==0) {
            sprintf(obuf,"param %s",o->arg1);
        } else if (strcmp(o->kind,"call")==0) {
            sprintf(obuf,"%s = call %s",o->result,o->arg1);
        } else if (strcmp(o->kind,"ret")==0) {
            sprintf(obuf,"return %s",o->arg1);
        } else if (strcmp(o->kind,"printf")==0) {
            sprintf(obuf,"printf %s",o->result);
        } else {
            sprintf(obuf,"?");
        }

        if (flags[i] == FLAG_NONE) {
            printf("    %-35s  [No change]\n", obuf);
        } else if (flags[i] == FLAG_CF) {
            if (strcmp(n->kind,"_dead_")==0)
                sprintf(nbuf,"<removed by DCE>");
            else if (strlen(n->op)>0)
                sprintf(nbuf,"%s = %s %s %s",n->result,n->arg1,n->op,n->arg2);
            else
                sprintf(nbuf,"%s = %s",n->result,n->arg1);
            printf("    %-35s  --> [Constant Folding] %s\n", obuf, nbuf);
            any_opt = 1;
        } else if (flags[i] == FLAG_DCE || strcmp(n->kind,"_dead_")==0) {
            printf("    %-35s  --> [Dead Code Eliminated]\n", obuf);
            any_opt = 1;
        }
    }

    if (!any_opt)
        printf("    (No optimizations applicable for this input)\n");

    /* Remove _dead_ instructions */
    int new_count = 0;
    for (int i = 0; i < tac_count; i++)
        if (strcmp(tac[i].kind,"_dead_")!=0)
            tac[new_count++] = tac[i];
    tac_count = new_count;

    printf("\n  Optimized TAC:\n");
    for (int i = 0; i < tac_count; i++) {
        TACInstr *t = &tac[i];
        if (strcmp(t->kind,"assign")==0) {
            if (strlen(t->op)>0)
                printf("    %s = %s %s %s\n",t->result,t->arg1,t->op,t->arg2);
            else
                printf("    %s = %s\n",t->result,t->arg1);
        } else if (strcmp(t->kind,"label")==0) {
            printf("  %s:\n",t->result);
        } else if (strcmp(t->kind,"goto")==0) {
            printf("    goto %s\n",t->result);
        } else if (strcmp(t->kind,"ifgoto")==0) {
            printf("    if %s %s %s goto %s\n",t->arg1,t->op,t->arg2,t->result);
        } else if (strcmp(t->kind,"param")==0) {
            printf("    param %s\n",t->arg1);
        } else if (strcmp(t->kind,"call")==0) {
            printf("    %s = call %s\n",t->result,t->arg1);
        } else if (strcmp(t->kind,"ret")==0) {
            printf("    return %s\n",t->arg1);
        } else if (strcmp(t->kind,"printf")==0) {
            printf("    printf %s\n",t->result);
        }
    }
}
