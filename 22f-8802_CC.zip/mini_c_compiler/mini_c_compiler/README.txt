=====================================================
  Mini-C Compiler — README
  FAST National University, CFD Campus
  Compiler Construction Project
=====================================================

REQUIREMENTS
------------
- Linux / macOS (or Windows with WSL/MinGW)
- GCC
- Flex  (sudo apt install flex)
- Bison (sudo apt install bison)

BUILD STEPS
-----------
1. Open a terminal in the project root directory.
2. Run:
       make
   This will:
   - Generate parser.tab.c / parser.tab.h from parser.y (Bison)
   - Generate lex.yy.c from lexer.l (Flex)
   - Compile all .c files
   - Link into build/minicc

3. To clean build artifacts:
       make clean

RUN
---
    ./build/minicc tests/test1_simple.c
    ./build/minicc tests/test2_ifelse.c
    ./build/minicc tests/test3_function_loop.c

OUTPUT
------
The compiler prints output for ALL phases in order:

  PHASE 1 — Lexical Analysis     : Token stream table
  PHASE 2 — Syntax Analysis      : Indented parse tree
  PHASE 3 — Semantic Analysis    : Symbol table + error report
  PHASE 4 — Intermediate Code    : Three-Address Code (TAC)
  PHASE 5 — Code Optimization    : Constant Folding + Dead Code Elimination
  PHASE 6 — Target Code          : x86 pseudo-assembly
  PHASE 7 — Program Execution    : TAC interpreter output

SOURCE FILES
------------
  src/lexer.l       — Flex lexer (Phase 1)
  src/parser.y      — Bison grammar + parse tree (Phase 2)
  src/ast.h         — AST node types, symbol table, TAC structures
  src/ast.c         — AST helpers, symbol table, TAC storage
  src/semantic.c    — Semantic analysis (Phase 3)
  src/codegen.c     — TAC generation (Phase 4)
  src/optimize.c    — Optimization (Phase 5)
  src/target.c      — Target code generation (Phase 6)
  src/interpreter.c — TAC interpreter / execution (Phase 7)
  src/main.c        — Main driver

SUPPORTED C SUBSET
------------------
  - Data type: int only
  - Variable declarations: int x; / int x = 5;
  - Arithmetic: + - * / with precedence and parentheses
  - Assignment: x = expr;
  - Relational: < > <= >= == !=
  - if / if-else (nested)
  - while loop
  - Function declarations and calls (int return type)
  - return statement
  - Single-line comments: // ...
