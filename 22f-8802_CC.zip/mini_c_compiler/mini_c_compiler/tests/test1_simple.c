// Test 1: Simple arithmetic assignment
int main() {
    int x = 5 + 3 * 2;
    int y = x - 4;
    return y;
}
