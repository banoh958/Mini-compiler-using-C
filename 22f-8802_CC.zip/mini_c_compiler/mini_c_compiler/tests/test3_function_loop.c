// Test 3: Function with a for loop (factorial)
int factorial(int n) {
    int result = 1;
    int i = 1;
    while (i <= n) {
        result = result * i;
        i = i + 1;
    }
    return result;
}

int main() {
    int ans = factorial(5);
    return ans;
}
