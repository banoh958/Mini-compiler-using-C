// Test 2: if-else with nested condition
int main() {
    int x = 10;
    int y = 20;
    int result = 0;
    if (x < y) {
        result = y - x;
    } else {
        result = x - y;
    }
    return result;
}
